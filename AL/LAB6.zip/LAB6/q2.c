#include <stdio.h>

int opcount = 0;

void swap(int *a, int *b){
	int temp = *a;
	*a = *b;
	*b = temp;
}

int partition(int arr[], int low, int high){
	int pivot=arr[low], pi=low, i=low-1, j=high+1;
	printf("Low %d high %d\n",i,j);
	while(i<=j){
		opcount += 2;
	//	i++;
	//	j--;
		while(arr[++i] <= pivot)
			printf("%d ",i);
		printf("\n");
		while(arr[--j] >= pivot)
			printf("%d ",j);
		//if(i<=j)
		printf("\nSwapping %d %d\n",i,j);
		swap(&arr[i],&arr[j]);
		//pi = i;
	}
	swap(&arr[i],&arr[j]);
	swap(&arr[j],&arr[pi]);
	return j;
}

void quickSort(int array[], int low, int high){
	if(low<high){
		int p = partition(array,low,high);

		quickSort(array,low,p-1);
		quickSort(array,p+1,high);
	}
}

void main(){
	int n,i;
	printf("Enter the size of array: ");
	scanf("%d",&n);
	int arr[n];
	printf("Enter the elements: ");
	for(i=0;i<n;i++)
		scanf("%d",&arr[i]);

	quickSort(arr,0,n-1);

	printf("Sorted array is: \n");
	for(i=0;i<n;i++)
		printf("%d ",arr[i]);

	printf("\nOpcount: %d\n",opcount);
}